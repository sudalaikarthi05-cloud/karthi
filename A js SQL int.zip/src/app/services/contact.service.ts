import { Injectable } from '@angular/core';
import { SupabaseService } from './supabase.service';
import { Contact } from '../models/contact.model';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  constructor(private supabaseService: SupabaseService) {}

  async getContacts(): Promise<Contact[]> {
    const { data, error } = await this.supabaseService
      .getClient()
      .from('contacts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching contacts:', error);
      return [];
    }

    return data || [];
  }

  async getContact(id: string): Promise<Contact | null> {
    const { data, error } = await this.supabaseService
      .getClient()
      .from('contacts')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching contact:', error);
      return null;
    }

    return data;
  }

  async createContact(contact: Contact): Promise<Contact | null> {
    const { data, error } = await this.supabaseService
      .getClient()
      .from('contacts')
      .insert([contact])
      .select()
      .single();

    if (error) {
      console.error('Error creating contact:', error);
      return null;
    }

    return data;
  }

  async updateContact(id: string, contact: Partial<Contact>): Promise<Contact | null> {
    const { data, error } = await this.supabaseService
      .getClient()
      .from('contacts')
      .update(contact)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating contact:', error);
      return null;
    }

    return data;
  }

  async deleteContact(id: string): Promise<boolean> {
    const { error } = await this.supabaseService
      .getClient()
      .from('contacts')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting contact:', error);
      return false;
    }

    return true;
  }
}
