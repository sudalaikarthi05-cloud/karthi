import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact.model';

@Component({
  selector: 'app-contact-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  contact: Contact = {
    name: '',
    email: '',
    phone: ''
  };
  isEditMode = false;
  contactId: string | null = null;
  loading = false;
  saving = false;

  constructor(
    private contactService: ContactService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  async ngOnInit() {
    this.contactId = this.route.snapshot.paramMap.get('id');

    if (this.contactId && this.contactId !== 'new') {
      this.isEditMode = true;
      await this.loadContact();
    }
  }

  async loadContact() {
    this.loading = true;
    const contact = await this.contactService.getContact(this.contactId!);

    if (contact) {
      this.contact = contact;
    } else {
      alert('Contact not found');
      this.router.navigate(['/']);
    }

    this.loading = false;
  }

  async onSubmit() {
    if (!this.contact.name || !this.contact.email || !this.contact.phone) {
      alert('Please fill in all fields');
      return;
    }

    this.saving = true;

    if (this.isEditMode && this.contactId) {
      const updated = await this.contactService.updateContact(this.contactId, this.contact);
      if (updated) {
        this.router.navigate(['/']);
      } else {
        alert('Failed to update contact');
      }
    } else {
      const created = await this.contactService.createContact(this.contact);
      if (created) {
        this.router.navigate(['/']);
      } else {
        alert('Failed to create contact');
      }
    }

    this.saving = false;
  }

  cancel() {
    this.router.navigate(['/']);
  }
}
