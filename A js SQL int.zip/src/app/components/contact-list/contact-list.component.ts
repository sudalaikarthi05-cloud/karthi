import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact.model';

@Component({
  selector: 'app-contact-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  contacts: Contact[] = [];
  loading = true;

  constructor(
    private contactService: ContactService,
    private router: Router
  ) {}

  async ngOnInit() {
    await this.loadContacts();
  }

  async loadContacts() {
    this.loading = true;
    this.contacts = await this.contactService.getContacts();
    this.loading = false;
  }

  addContact() {
    this.router.navigate(['/contact/new']);
  }

  editContact(id: string) {
    this.router.navigate(['/contact/edit', id]);
  }

  async deleteContact(id: string) {
    if (confirm('Are you sure you want to delete this contact?')) {
      const success = await this.contactService.deleteContact(id);
      if (success) {
        await this.loadContacts();
      }
    }
  }
}
