export const environment = {
  production: false,
  supabaseUrl: 'https://izzwsrqjkidmkrtbdvtl.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml6endzcnFqa2lkbWtydGJkdnRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwNzcxMTAsImV4cCI6MjA3NTY1MzExMH0.aI0tiKM1MUwkmxNdIoQBehqVfsqZOX3xh_mKd6d50r8'
};
