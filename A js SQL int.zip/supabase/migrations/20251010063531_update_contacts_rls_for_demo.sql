/*
  # Update contacts RLS policies for demo access
  
  1. Changes
    - Drop existing restrictive RLS policies
    - Add new policies that allow public access for demo purposes
    - Make user_id nullable to support unauthenticated users
    - Add default value for user_id
  
  2. Security Notes
    - This configuration is for demo/development only
    - In production, proper authentication should be required
    - All users can access all contacts in this configuration
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own contacts" ON contacts;
DROP POLICY IF EXISTS "Users can insert own contacts" ON contacts;
DROP POLICY IF EXISTS "Users can update own contacts" ON contacts;
DROP POLICY IF EXISTS "Users can delete own contacts" ON contacts;

-- Make user_id nullable and add default
ALTER TABLE contacts ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE contacts ALTER COLUMN user_id SET DEFAULT '00000000-0000-0000-0000-000000000000'::uuid;

-- Create new permissive policies for demo access
CREATE POLICY "Allow public to view all contacts"
  ON contacts FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow public to insert contacts"
  ON contacts FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow public to update contacts"
  ON contacts FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public to delete contacts"
  ON contacts FOR DELETE
  TO anon, authenticated
  USING (true);