/*
  # Create contacts table
  
  1. New Tables
    - `contacts`
      - `id` (uuid, primary key) - Unique identifier for each contact
      - `name` (text, required) - Contact's full name
      - `email` (text, required) - Contact's email address
      - `phone` (text, required) - Contact's phone number
      - `user_id` (uuid, required) - Reference to the user who owns this contact
      - `created_at` (timestamptz) - Timestamp when contact was created
      - `updated_at` (timestamptz) - Timestamp when contact was last updated
  
  2. Security
    - Enable RLS on `contacts` table
    - Add policy for authenticated users to view their own contacts
    - Add policy for authenticated users to insert their own contacts
    - Add policy for authenticated users to update their own contacts
    - Add policy for authenticated users to delete their own contacts
  
  3. Important Notes
    - All contacts are user-specific and isolated by user_id
    - RLS ensures users can only access their own contacts
    - Timestamps are automatically managed with defaults and triggers
*/

CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own contacts"
  ON contacts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own contacts"
  ON contacts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own contacts"
  ON contacts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own contacts"
  ON contacts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();